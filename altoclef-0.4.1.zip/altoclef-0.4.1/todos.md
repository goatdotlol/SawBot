# TODO's: Long Term Future Features

- Smart tasks that are user customizable. Give resources json-assignable descriptions on how they CAN be obtained, and the system automatically tries to obtain it in the fastest way.
- Given any schematic, Collect ALL resources and BUILD the schematic, ideally from a fresh survival world if possible.
- Initialize and control multiple bots over a network. Kind of like an RTS game.
- Make this bot able to survive anarchy
- All acheivements, fully autonomous (not happening any time soon lol)